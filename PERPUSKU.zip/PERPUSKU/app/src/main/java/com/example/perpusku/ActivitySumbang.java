package com.example.perpusku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivitySumbang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sumbang);
    }
}