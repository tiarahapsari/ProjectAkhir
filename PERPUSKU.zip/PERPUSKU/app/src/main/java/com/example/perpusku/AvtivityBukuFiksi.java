package com.example.perpusku;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class AvtivityBukuFiksi extends AppCompatActivity {

    RecyclerView recyclerView;

    String s1[], s2[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fiksi);

        recyclerView = findViewById(R.id.recyclerFiksi);

        s1 = getResources().getStringArray(R.array.list_fiksi);
        s2 = getResources().getStringArray(R.array.penulis);

        MyAdapterFiksi adapterFiksi = new MyAdapterFiksi(this, s1, s2);
        recyclerView.setAdapter(adapterFiksi);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}