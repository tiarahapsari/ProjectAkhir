package com.example.perpusku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnFiksi;
    Button btnTamu;
    Button btnSumbang;
    private Object Intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnFiksi = findViewById(R.id.btnFiksi);
        btnFiksi.setOnClickListener(this);

        btnTamu = findViewById(R.id.btnTamu);
        btnTamu.setOnClickListener(this);

        btnSumbang = findViewById(R.id.btnSumbang);
        btnSumbang.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnFiksi:
                Intent m = new Intent(this, AvtivityBukuFiksi.class);
                startActivity(m);
                break;

            case R.id.btnTamu:
                Intent x = new Intent(this, ActivityTamu.class);
                startActivity(x);
                break;

            case R.id.btnSumbang:
                Intent y = new Intent(this, ActivitySumbang.class);
                startActivity(y);
                break;
        }
    }




}