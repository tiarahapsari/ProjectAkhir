package com.example.perpusku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    EditText namainput, alamatinput, umurinput;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        namainput = findViewById(R.id.nama_input);
        alamatinput = findViewById(R.id.alamat_input);
        umurinput = findViewById(R.id.umur_input);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);
                myDB.addBook(namainput.getText().toString().trim(),
                        alamatinput.getText().toString().trim(),
                        Integer.valueOf(umurinput.getText().toString().trim()));
            }
        });
    }
}