package com.example.perpusku;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ActivityTamu extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamu);

        recyclerView = findViewById(R.id.recyclerTamu);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener((view) -> {
                Intent intent = new Intent(ActivityTamu.this, AddActivity.class);
                startActivity(intent);

        });
    }
}